// API key
const API_KEY = "pk.eyJ1IjoiamluYmlsbHMiLCJhIjoiY2p1NGZtNm9hMHhqazQ1cDhybXh2Mjl6MCJ9.eq6bgxgDo5BkzFsppZoFsg";
const googlekey="AIzaSyCMFgUNH7VnOnWR7o-x5QtmnlPf4VaujTU"
